package es.ucm.fdi.iw.g01.bayshop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BayshopApplicationTests {

	@Test
	void contextLoads() {
	}

}
